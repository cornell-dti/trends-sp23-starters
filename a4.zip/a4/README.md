# Trends A4 Starter Code

In this project we make a task tracker using Firebase.
