module.exports = {
  images: {
    domains: [],
  },
}