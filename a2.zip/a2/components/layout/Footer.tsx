import React from "react";

const Footer = () => (
  <footer>
    <hr />
    <span>Created by [TODO My name (netid)]</span>
  </footer>
);

export default Footer;
