export type ClubMember = {
  name: string,
  netid: string,
  partyParrot: string,
  favoriteIceCream: string,
  /* TODO Add TWO MORE fields! (eg. role in club) */
}
