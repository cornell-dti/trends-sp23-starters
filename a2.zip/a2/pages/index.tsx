import Layout from "../components/layout/Layout"

const IndexPage = () => (
  <Layout title="Home">
    <h1>My Trends A2 Project</h1>
    <p>I am part of a cool club and I also collect BRBs as a hobby.</p>
    <p>I worked on this assignment for [TODO x] hours.</p>
  </Layout>
)

export default IndexPage
