module.exports = {
  images: {
    domains: ['cultofthepartyparrot.com'],
  },
}