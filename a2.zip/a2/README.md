# Trends A2 Starter Code

This is a really simple project where you will make a club roster and an incremental game.
