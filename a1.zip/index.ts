// QUESTION 1 ------------------------------------------------------------------

export const arrayMean = (array: number[]): number | undefined => {
    /* TODO: add your code */
};

// QUESTION 2 ------------------------------------------------------------------

type Apartment = {
    id: string;
    rent: number;
};

export const affordableHousing = (
    listings: Apartment[],
    budget: number
): string[] => {
    /* TODO: add your code */
};

// QUESTION 3 ------------------------------------------------------------------

export const evenEven = (array?: string[]): boolean => {
    /* TODO: add your code */
};

// QUESTION 4 ------------------------------------------------------------------

// TODO: You should replace this any with an accurate object type in your submission!
type Doggo = any;

export const makeSentences = (array: Doggo[]): string[] => {
    /* TODO: add your code */
};
